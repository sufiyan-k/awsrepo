
namespace Company;

public class Employee{
    public string Firstname{get;set;}
    public string Lastname{get;set;}
    public string Mob{get;set;}
    public string Email{get;set;}
    public string Password{get;set;}
    public Employee(string fn,string ln,string m,string e,string p){

        Firstname=fn;
        Lastname=ln;
        Mob=m;
        Email=e;
        Password=p;

    }
}
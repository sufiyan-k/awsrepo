﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mystore.Models;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Company;



namespace mystore.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult Register(){
        return View();
    }
    public IActionResult Login(){
        return View();
    }
    public IActionResult Aboutus(){
        return View();
    }
    public IActionResult Postregister(string firstname,string lastname,string contactnumber,string email,string password){
        Employee emp=new Employee (firstname,lastname,contactnumber,email,password);
        var options=new JsonSerializerOptions {IncludeFields=true};
        var myjson=JsonSerializer.Serialize<Employee>(emp,options);
        Console.WriteLine(myjson);
        string path=@"D:\Sufiyan and sahil\dotnet_data\My_work\My_WebApp\emp.json";
        //serialize all the worklist in the json file
        System.IO.File.AppendAllText(path,myjson);
        return View();
    }

       public IActionResult Validate(string email, string password){

         Console.WriteLine("Validating User credentials.... ");
       

        if(email =="sufi@gmail.com" && 
           password=="sufi"){
             Console.WriteLine("successfull validation of user..... ");
             Console.WriteLine("Redirecting to welcome..... ");   
            return Redirect("/home/Welcome");
           }
        return View();
    }
    public IActionResult Welcome(){
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

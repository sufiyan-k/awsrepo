
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mystore.Models;

public class ShoppingController:Controller{
      private readonly ILogger<ShoppingController> _logger;

    public ShoppingController(ILogger<ShoppingController> logger)
    {
        _logger = logger;
    }

     public IActionResult Shopnow(){
        return View();
    }

}